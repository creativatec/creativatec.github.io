$(document).ready(function() {
    $('#usuario').DataTable();
} );

$(document).ready(function() {
    $('#producto').DataTable();
} );

$(document).ready(function() {
    $('#proevedor').DataTable();
} );