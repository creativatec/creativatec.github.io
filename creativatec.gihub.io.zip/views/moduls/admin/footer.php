</div>
</div>

<div id="spinner" class="spinner" style="display:none;">
    Loading&hellip;
</div>

<footer class="application-footer">
    <div class="container">
        <p>Application Footer</p>
        <div class="disclaimer">
            <p>This is an example disclaimer. All right reserved.</p>
            <p>Copyright © keaplogik 2011-2012</p>
        </div>
    </div>
</footer>